#pragma once
#include "dssim.h"

void do_args(int argc, char* argv[], dssim_t::Config& con);
